Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/login-with-google-account-using-javascript/

============ Introduction ============
This project will help web developers to integrate Google Sign-In without page refresh using JavaScript at their web application.

============ Installation ============
Open the index.html file and Specify your app's Client ID which you have created in the Google Developers Console in the google-signin-client_id meta element.

============ May I Help You ===========
If you have any query about this script, send us by posting a comment here - http://www.codexworld.com/login-with-google-account-using-javascript/#respond